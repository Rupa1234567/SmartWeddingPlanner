package com.smart.wedding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartweddingApplicationTests {

	@Test
	void contextLoads() {
	}

}
