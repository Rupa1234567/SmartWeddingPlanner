package com.smart.wedding.dto;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "submit") // Ensure this matches the table name
@Data
public class ContactRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String phone;
    private String message;
}
