package com.smart.wedding.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class UserDetails {
	
	private String fullname;
	
	private String phoneNumber;
	
	private String email;
	
	private String password;

	

}
