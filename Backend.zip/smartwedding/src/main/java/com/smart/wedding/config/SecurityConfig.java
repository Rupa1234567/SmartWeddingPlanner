package com.smart.wedding.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Disable CSRF for simplicity (especially for development)
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/user/register",
                    "/user/login",
                    "/user/submit",
                    "/user/booking",
                    "/user/forgot-password",
                    "/user/reset-password"
                ).permitAll() // Allow unauthenticated access to these endpoints
                .anyRequest().authenticated() // Require authentication for everything else
            );

        return http.build();
    }
}
