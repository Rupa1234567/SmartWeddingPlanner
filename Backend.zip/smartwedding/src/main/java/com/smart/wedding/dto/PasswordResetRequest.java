package com.smart.wedding.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class PasswordResetRequest {
	
    private String email;
    
    private String newPassword;
    
    private String confirmPassword;
}