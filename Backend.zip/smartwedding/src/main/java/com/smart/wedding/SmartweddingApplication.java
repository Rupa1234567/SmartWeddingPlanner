package com.smart.wedding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.smart.wedding")
public class SmartweddingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartweddingApplication.class, args);
	}

}
