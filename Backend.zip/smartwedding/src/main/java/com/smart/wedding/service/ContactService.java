package com.smart.wedding.service;

import com.smart.wedding.dto.ContactRequest;
import com.smart.wedding.repository.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactService {

    @Autowired
    private ContactRepository contactRepository;

    public void saveContactRequest(ContactRequest request) {
        System.out.println("Saving Contact Request: " + request); // Logging statement added
        contactRepository.save(request);
    }
}
