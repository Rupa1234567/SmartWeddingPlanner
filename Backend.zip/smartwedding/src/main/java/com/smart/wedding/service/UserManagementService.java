package com.smart.wedding.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.smart.wedding.dto.UserDetailsEntity;
import com.smart.wedding.dto.UserLoginDetails;
import com.smart.wedding.repository.UserManagementRepository;
import com.smart.wedding.dto.UserDetails;
import com.smart.wedding.dto.PasswordResetRequest;
import java.util.Optional;

@Service
public class UserManagementService {

    @Autowired
    UserManagementRepository userManagementRepository;

 
    // Create a new user
    public String createUser(UserDetails userDetails) {
        // Check if the email is already registered
        Optional<UserDetailsEntity> existingUser = userManagementRepository.findByEmail(userDetails.getEmail());
        if (existingUser.isPresent()) {
            return "User already registered!";
        }

        // Object Mapping : Object Mappers / mapStruct
        UserDetailsEntity entity = new UserDetailsEntity();
        entity.setEmail(userDetails.getEmail());
        entity.setPassword(userDetails.getPassword()); // Encrypt in production
        entity.setFullname(userDetails.getFullname());
        entity.setPhoneNumber(userDetails.getPhoneNumber());

        // Save the new user
        userManagementRepository.save(entity);  

        return "User Registered Successfully";
    }

    // User Login
    public UserDetails userLogin(UserLoginDetails userLoginDetails) {
        UserDetailsEntity userData = userManagementRepository.findByEmailAndPassword(
            userLoginDetails.getEmail(), userLoginDetails.getPassword()
        );

        UserDetails userDetails = null;
        if (userData != null) {
            userDetails = new UserDetails();
            userDetails.setEmail(userData.getEmail());
            userDetails.setFullname(userData.getFullname());
            userDetails.setPhoneNumber(userData.getPhoneNumber());
        }
        return userDetails;
    }

    // Request Password Reset
    public String forgotPassword(String email) {
        Optional<UserDetailsEntity> user = userManagementRepository.findByEmail(email);

        if (user.isPresent()) {
            // You can generate an OTP and email it or use a token for reset
            return "Password reset link has been sent to your email.";
        }
        return "User not found!";
    }

    // Reset Password with Re-enter Password Validation
    public String resetPassword(PasswordResetRequest request) {
        Optional<UserDetailsEntity> user = userManagementRepository.findByEmail(request.getEmail());

        if (user.isPresent()) {
            if (!request.getNewPassword().equals(request.getConfirmPassword())) {
                return "Passwords do not match!";
            }
            
            UserDetailsEntity existingUser = user.get();
            existingUser.setPassword(request.getNewPassword()); // Encrypt in production
            userManagementRepository.save(existingUser);
            return "Password updated successfully!";
        }
        return "User not found!";
    }

}
