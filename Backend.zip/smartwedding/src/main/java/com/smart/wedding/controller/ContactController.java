package com.smart.wedding.controller;

import com.smart.wedding.dto.ContactRequest;
import com.smart.wedding.service.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/user")
public class ContactController {

    @Autowired
    private ContactService contactService;

    @PostMapping("/submit")
    public ResponseEntity<Map<String, String>> submitContactForm(@RequestBody ContactRequest request) {
        contactService.saveContactRequest(request);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Your message has been received! We will get back to you soon.");
        
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}
