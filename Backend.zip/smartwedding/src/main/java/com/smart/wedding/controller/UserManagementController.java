package com.smart.wedding.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.smart.wedding.dto.UserDetails;
import com.smart.wedding.dto.UserLoginDetails;
import com.smart.wedding.service.UserManagementService;
import com.smart.wedding.dto.PasswordResetRequest;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/user") // Common base URL
public class UserManagementController {

    // Dependency Injection
    @Autowired
    UserManagementService userManagementService;

    // User Registration
    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> createUser(@RequestBody UserDetails userDetails) {
        System.out.println("User Details : Register : " + userDetails);

        String result = userManagementService.createUser(userDetails);

        // Returning JSON response instead of plain text
        Map<String, String> response = new HashMap<>();
        response.put("message", result);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // User Login
    @PostMapping("/login")
    public ResponseEntity<UserDetails> userLogin(@RequestBody UserLoginDetails userLoginDetails) {
        UserDetails userData = userManagementService.userLogin(userLoginDetails);
        
        if (userData != null) {
            return new ResponseEntity<>(userData, HttpStatus.OK);
        }
        return new ResponseEntity<>(userData, HttpStatus.UNAUTHORIZED);
    }

    // Forgot Password
    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, String>> forgotPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String result = userManagementService.forgotPassword(email);

        Map<String, String> response = new HashMap<>();
        response.put("message", result);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // Reset Password
    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, String>> resetPassword(@RequestBody PasswordResetRequest request) {
        String result = userManagementService.resetPassword(request);

        Map<String, String> response = new HashMap<>();
        response.put("message", result);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

   
}
