package com.smart.wedding.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter

public class UserLoginDetails {
	
    private String email;
	
	private String password;

}
