package com.smart.wedding.service;

import com.smart.wedding.dto.Booking;
import com.smart.wedding.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public String saveBooking(Booking booking) {
        if (bookingRepository.existsByDate(booking.getDate())) {
            return "Booking already exists for this date. Please select another date.";
        }
        bookingRepository.save(booking);
        return "Booking successful!";
    }
}
