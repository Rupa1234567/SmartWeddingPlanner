package com.smart.wedding.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "register", uniqueConstraints = @UniqueConstraint(columnNames = "phoneNumber"))

public class UserDetailsEntity {
	
	@Id
	@Column(nullable = false, unique = true)
	private String email;
	
	@Column(name = "phoneNumber", nullable = false, unique = true)
    private String phoneNumber;
	
	@Column(nullable = false)
	private String fullname;
	
	@Column(nullable = false)
	private String password;

	
}
