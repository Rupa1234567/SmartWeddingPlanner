package com.smart.wedding.controller;

import com.smart.wedding.dto.Booking;
import com.smart.wedding.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:3008")
public class BookingController {
    @Autowired
    private BookingRepository bookingRepository;

    // Save booking data
    @PostMapping("/booking")
    public ResponseEntity<?> saveBooking(@RequestBody Booking booking) {
        try {
            // This is where the booking data is saved to the database
            bookingRepository.save(booking);

            // If saving was successful, send a success message
            return ResponseEntity.ok("{\"message\":\"Booking successful!\"}");
        } catch (Exception e) {
            e.printStackTrace(); // Log the actual error for debugging
            // In case of an error, send an error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("{\"message\":\"Failed to save booking.\"}");

        }
    }
}
