package com.smart.wedding.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.smart.wedding.dto.UserDetailsEntity;
import java.util.Optional;

@Repository
public interface UserManagementRepository extends JpaRepository<UserDetailsEntity, String> {

    // Custom findBy Method
    UserDetailsEntity findByEmailAndPassword(String email, String password);

    // Check if email already exists
    Optional<UserDetailsEntity> findByEmail(String email);
}
