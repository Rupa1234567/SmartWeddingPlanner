package com.smart.wedding.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    private String date; // This will now be the primary key

    private String name;
    private String email;
    private String phone;
    private String location;
    private String preferredVenue;
    private int guests;
    private String guestPass; // Added field for guest pass
}
